import{c as s}from"./main-BFMiUjhv.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-DjqjOpWB.js.map
