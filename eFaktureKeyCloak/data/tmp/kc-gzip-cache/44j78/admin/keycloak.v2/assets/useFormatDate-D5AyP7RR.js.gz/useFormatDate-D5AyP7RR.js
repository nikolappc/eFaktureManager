import{cX as n}from"./main-BFMiUjhv.js";const s={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{s as F,l as u};
//# sourceMappingURL=useFormatDate-D5AyP7RR.js.map
