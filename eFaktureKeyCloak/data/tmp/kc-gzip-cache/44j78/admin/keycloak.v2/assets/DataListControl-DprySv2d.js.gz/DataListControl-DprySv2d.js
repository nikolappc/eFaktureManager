import{as as e,ar as o}from"./main-BFMiUjhv.js";import*as m from"react";import{s as i}from"./DataListItemRow-CnebIWTo.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-DprySv2d.js.map
