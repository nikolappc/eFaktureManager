import{jsx as a}from"react/jsx-runtime";import{a as r,X as n}from"./main-BFMiUjhv.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-CeEYxvq3.js.map
