import{cd as o}from"./main-BFMiUjhv.js";const n=r=>t=>t&&o(r,t)||"—";export{n as t};
//# sourceMappingURL=translationFormatter-BkpXPgnr.js.map
